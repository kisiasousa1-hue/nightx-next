package com.nightx.next

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.nightx.next.api.NightXApi
import com.nightx.next.api.NightXMode
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var status: TextView
    private val permCode = 1001

    private val onBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0D1226"))
            setPadding(48, 48, 48, 48)
        }
        val title = TextView(this).apply {
            text = "nightX"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 18f
            setTextColor(Color.parseColor("#CFD9FF"))
            gravity = Gravity.CENTER
            setPadding(0, 48, 0, 48)
        }
        val btnPerm = Button(this).apply {
            text = "Pedir permissao"
            setOnClickListener {
                if (Shizuku.pingBinder()) NightXApi.requestPermission(permCode)
                refresh()
            }
        }
        val btnRefresh = Button(this).apply {
            text = "Atualizar"
            setOnClickListener { refresh() }
        }
        root.addView(title)
        root.addView(status)
        root.addView(btnPerm)
        root.addView(btnRefresh)
        setContentView(root)

        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addRequestPermissionResultListener(onPerm)
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeRequestPermissionResultListener(onPerm)
        super.onDestroy()
    }

    private fun refresh() {
        status.text = when (NightXApi.mode()) {
            NightXMode.NOT_RUNNING -> "O Shizuku nao esta rodando.\nInicie o Shizuku e tente de novo."
            NightXMode.NO_PERMISSION -> "Permissao pendente.\nToque em \"Pedir permissao\"."
            NightXMode.ROOT -> "AVISO: Este aparelho esta com ROOT.\n(nightX rodando como root)"
            NightXMode.ADB -> "Rodando por ADB (sem root)."
        }
    }
}
