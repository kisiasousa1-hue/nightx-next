package com.nightx.next.api

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Estados possiveis do nightX (baseado no Shizuku). */
enum class NightXMode { NOT_RUNNING, NO_PERMISSION, ROOT, ADB }

/** API do nightX: com.nightx.next.api */
object NightXApi {

    fun mode(): NightXMode {
        if (!Shizuku.pingBinder()) return NightXMode.NOT_RUNNING
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED)
            return NightXMode.NO_PERMISSION
        // uid 0 = Shizuku rodando como root; 2000 = rodando via ADB (shell)
        return if (Shizuku.getUid() == 0) NightXMode.ROOT else NightXMode.ADB
    }

    fun requestPermission(requestCode: Int) = Shizuku.requestPermission(requestCode)
}
