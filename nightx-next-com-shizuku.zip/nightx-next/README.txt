nightX (com.nightx.next) - projeto Android em Kotlin
API: com.nightx.next.api.NightXApi (usa a API do Shizuku)

COMO GERAR O APK
1. Instale o Android Studio.
2. File > Open e escolha esta pasta (nightx-next).
3. Espere o Gradle sincronizar (precisa de internet).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK fica em app/build/outputs/apk/debug/

Se o Gradle reclamar de versao, atualize as versoes em build.gradle.kts.
Nao foi testado: eu nao consigo compilar nem rodar Android aqui.
